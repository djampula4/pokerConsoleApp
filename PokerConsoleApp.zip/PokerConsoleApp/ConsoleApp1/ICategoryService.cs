﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker
{
    public interface ICategoryService
    {
        /// <summary>
        /// It returns the rank of the player, based on the hand
        /// </summary>
        /// <returns></returns>
        public int Hand();

        public bool IsFlush();

        public bool IsOnePair();

        public bool IsTwoPair();

        public bool IsStraight();

        public void GetHighCard();

        /// <summary>
        /// Return pairs of cards
        /// eg: 3 3 4 5 6 -> output 1 
        /// eg: 3 3 4 4 6 -> output 2
        /// </summary>
        /// <returns></returns>
        public int FindPairs();
    }
}
