﻿using Poker.Symbol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker
{
    public interface IPokerService : ICategoryService
    {
        public void play(Player player);
        
        /// <summary>
        /// Reads the category patterns of the player
        /// </summary>
        /// <param name="player"></param>
        public void GetPattern(Dictionary<Suit,List<string>> cards);

        public void FindHighestRank();
    }
}
