﻿using Poker.Symbol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker
{
    public class Player
    {
        public string PlayerName;
        public readonly List<Suit> _suit;
        public readonly List<string> _value;
        public readonly Dictionary<Suit, List<string>> _cards;
        public int rank;

        public Player()
        {
            _suit = new List<Suit>();
            _value = new List<string>();
            _cards = new Dictionary<Suit, List<string>>();
        }
        public Player(string playerName)
        {
            PlayerName = playerName;
            _suit = new List<Suit>();
            _value = new List<string>();
            _cards = new Dictionary<Suit, List<string>>();
        }

        public void AddCardsToThePlayer(Suit suit, string value)
        {
            this._suit.Add(suit);
            this._value.Add(value);

            List<string> list;

            if (!this._cards.TryGetValue(suit, out list))
            {
                this._cards.Add(suit, new List<string> { value });
            }
            else
            {
                list.AddRange(new List<string> { value });
                if (list.Count > 5)
                {
                    Console.WriteLine("Please make sure you can only have maximum of " + 5 + " cards!");
                }
                else
                {
                    this._cards[suit] = list;
                }

            }
        }
    }
}
