﻿using Poker.Symbol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Poker.Symbol;

namespace Poker
{
    public class PokerService : IPokerService
    {
        private readonly List<string> _values;
        private readonly List<Suit> _suit;
        private readonly Dictionary<string, int> _cardsDict;
        private Dictionary<string,int> _rankService;


        public readonly Dictionary<Suit, char> _cardSuit;

        #region symbols

        char club = '\u2663';
        char spade = '\u2660';
        char diamond = '\u2666';
        char heart = '\u2665';

        #endregion

        public PokerService()
        {
            _values = new List<string>();
            _suit = new List<Suit>();
            _cardsDict = new Dictionary<string, int>();
            _cardSuit = new Dictionary<Suit, char>();
            _rankService = new Dictionary<string, int>();

            _cardSuit.Add(Suit.Hearts, heart);
            _cardSuit.Add(Suit.Clubs, club);
            _cardSuit.Add(Suit.Diamonds, diamond);
            _cardSuit.Add(Suit.Spades, spade);


            CardIntValue();


        }

        public void CardIntValue()
        {
            for (int i = 1; i <= 13; i++)
            {
                if (i > 10)
                {
                    string c = (i == 11 ? "J" : i == 12 ? "Q" : "K");
                    _cardsDict.Add(c, i);
                }
                else if (i == 1)
                {
                    _cardsDict.Add("A", i);
                }
                else
                {
                    _cardsDict.Add(i.ToString(), i);
                }
            }
        }

        public void play(Player player)
        {
            if(player.PlayerName != null)
            {
                Console.Write(" --> " + player.PlayerName);
                if (!_rankService.ContainsKey(player.PlayerName))
                {
                    _rankService.Add(player.PlayerName, 0);

                    _suit.Clear();
                    _values.Clear();

                    _suit.AddRange(player._suit.ToList());
                    _values.AddRange(player._value.ToList());

                    GetPattern(player._cards);

                    _rankService[player.PlayerName] = Hand();
                    Console.WriteLine("\n\n");
                }
                else
                {
                    Console.WriteLine("\n Please give different name for " + player.PlayerName + ". It is already taken.");
                    Console.WriteLine(" Please try again.");
                    Console.WriteLine("\n\n");
                }
            }
            else
            {
                Console.WriteLine(" Please provide the player name.");
                Console.WriteLine("\n\n");
            }
            
        }


        public int Hand()
        {            
            /*
                Weightage of the hands

                1. Check if there are no card and return 0;
                2. Flush -> only needs shapes

                // below categories doesn't depend on shapes

                3. Straight
                4. Two pair
                5. One pair
                6. HighCard

             */
            if (_suit.Count == 0)
            {
                Console.Write(" No cards");
                return 0;
            }
            else if(_values.Count != 5)
            {
                Console.Write("  -> [Only 5 cards are allowed for each player. Please check your cards] ");
                return -1;
            }
            else if (IsFlush())
            {
                Console.Write(" FLUSH ");
                return 5;
            }
            else if (IsStraight())
            {
                Console.Write(" Straight ");
                return 4;
            }
            else if (IsTwoPair())
            {
                Console.Write(" Two Pair ");
                return 3;
            }
            else if (IsOnePair())
            {
                Console.Write(" One Pair ");
                return 2;
            }
            else
            {
                GetHighCard();
                return 1;
            }            
        }

        public void GetPattern(Dictionary<Suit, List<string>> cards)
        {
            Console.Write(" [ ");
            foreach (KeyValuePair<Suit, List<string>> keyValuePair in cards)
            {
                foreach(string card in keyValuePair.Value)
                {
                    Console.Write(" " + card.ToString() + _cardSuit[keyValuePair.Key]);
                }
                
            }
            Console.Write(" ] ");
        }

        public bool IsFlush()
        {
            if (_suit.Count == 5)
            {
                var firstElement = _suit.First();

                for (int i = 0; i < 5; i++)
                {
                    if (_suit[i] != firstElement)
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        public bool IsOnePair()
        {

            if (FindPairs() == 1)
                return true;

            return false;
        }

        public bool IsTwoPair()
        {
            if (FindPairs() == 2)
                return true;

            return false;
        }
        public bool IsStraight()
        {
            List<int> list = new List<int>();
            bool isStraight = true;

            foreach (string card in _values)
            {
                list.Add(_cardsDict[card]);
            }

            // Ascend the values
            var query = list.OrderBy(x => x).ToList();

            var elements = query.Take(2).ToArray();

            int a = elements[0] == 1 ? 1 : 0;
            int key = elements[a];

            for (int i = a; i < 5; i++)
            {
                if (query[i] == key)
                {
                    key = key + 1;
                }
                else
                {
                    isStraight = false;
                    break;
                }
            }

            return isStraight;
        }

        public void GetHighCard()
        {
            List<int> list = new List<int>();

            foreach (string card in _values)
            {
                list.Add(_cardsDict[card]);
            }

            var query = list.OrderBy(x => x).ToList();

            if (query.Contains(1))
            {
                Console.Write(" A is the HighCard ");
            }
            else
            {
                int i = query[query.Count - 1];

                if (i > 10)
                {
                    string c = (i == 11 ? "J" : i == 12 ? "Q" : "K");
                    Console.Write(" " + c + " is the HighCard ");
                }
                else
                {
                    Console.Write(" " + i + " is the HighCard ");
                }
            }
        }

        public int FindPairs()
        {
            var query = _values.GroupBy(x => x)
              .Where(g => (g.Count() == 2))
              .Select(y => new { Element = y.Key, Counter = y.Count() })
              .ToList();
            return query.Count;
        }

        public void FindHighestRank()
        {
            Console.WriteLine("*************************************\n");
            var highestRank = _rankService.Values.Max(); // This gives the highest rank
            var pairs = _rankService.Where(a => a.Value == highestRank).ToList(); // Check if someone has same rank 

            foreach (var pair in pairs)
            {
                Console.WriteLine(" The winner is [ " + pair.Key + " ] ");
            }

            Console.WriteLine("\n*************************************\n");

        }
    }
}
