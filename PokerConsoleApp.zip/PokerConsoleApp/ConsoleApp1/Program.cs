﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Poker.Symbol;
namespace Poker
{
    public class program
    {
        static void Main(string[] args)
        {
            Legend();

            Player player1 = new Player("player1");
            player1.AddCardsToThePlayer(Suit.Hearts, "3");
            player1.AddCardsToThePlayer(Suit.Spades, "Q");
            player1.AddCardsToThePlayer(Suit.Clubs, "4");
            player1.AddCardsToThePlayer(Suit.Clubs, "3");
            player1.AddCardsToThePlayer(Suit.Diamonds, "3");

            Player player2 = new Player("player2");
            player2.AddCardsToThePlayer(Suit.Clubs, "3");
            player2.AddCardsToThePlayer(Suit.Diamonds, "Q");
            player2.AddCardsToThePlayer(Suit.Diamonds, "4");
            player2.AddCardsToThePlayer(Suit.Hearts, "A");
            player2.AddCardsToThePlayer(Suit.Hearts, "2");

            Player player3 = new Player("player3");
            player3.AddCardsToThePlayer(Suit.Spades, "10");
            player3.AddCardsToThePlayer(Suit.Hearts, "Q");
            player3.AddCardsToThePlayer(Suit.Diamonds, "J");
            player3.AddCardsToThePlayer(Suit.Clubs, "A");
            player3.AddCardsToThePlayer(Suit.Clubs, "K");

            try
            {
                PokerService service = new PokerService();
                service.play(player1 as Player);
                service.play(player2 as Player);
                service.play(player3 as Player);
                service.FindHighestRank();
            }
            catch (Exception ex)
            {
                Console.WriteLine(" ERROR: " + ex.Message.ToString());
                Console.WriteLine(" \n\n");
            }

         

            
        }

        public static void Legend()
        {
            Console.WriteLine('\n');
            Console.WriteLine('\n');
            Console.WriteLine(" HAND        --> Rank ");
            Console.WriteLine(" -------------------- ");
            Console.WriteLine(" HIGHCARD    -->  1 ");
            Console.WriteLine(" ONE PAIR    -->  2 ");
            Console.WriteLine(" TWO PAIR    -->  3 ");
            Console.WriteLine(" STRAIGHT    -->  4 ");
            Console.WriteLine(" FLUSH       -->  5 ");
            Console.WriteLine(" -------------------- ");
            Console.WriteLine(" NOTE: Higher the rank is the winner of the game. ");
            Console.WriteLine('\n');
            Console.WriteLine('\n');

        }


    }
}
